CREATE TRIGGER delete_wagtailsearch_indexentry_fts AFTER DELETE ON wagtailsearch_indexentry BEGIN DELETE FROM wagtailsearch_indexentry_fts WHERE rowid=OLD.id; END;

