CREATE TRIGGER update_wagtailsearch_indexentry_fts AFTER UPDATE ON wagtailsearch_indexentry BEGIN UPDATE wagtailsearch_indexentry_fts SET title=NEW.title, body=NEW.body, autocomplete=NEW.autocomplete WHERE rowid=NEW.id; END;

